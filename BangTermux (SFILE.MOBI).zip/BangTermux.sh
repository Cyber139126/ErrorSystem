#!/bin/bash
#Bang Termux


clear
#color
b='\033[34;1m'  #   biru mud
g='\033[32;1m'    #hijau
p='\033[35;1m'   # ungu
c='\033[36;1m'     #biru tua 
r='\033[31;1m'   #   merah
w='\033[37;1m'  #  putih
y='\033[33;1m'  #   kining



echo $b "Nama Anda";
read Nama
sleep 2
echo $g "Selamat Datang" "$Nama"

echo $y "<|=========================|>"
echo $y "<|[01] SRIPT PERTAMA       |>"
echo $g "<|[02] KELUAR AJA          |>"
echo $g "<|=========================|>"
echo
read -p "DI PILIH GAN¤>" BangTermux;


clear
if [ $BangTermux = 01 ]
then
echo $r "SUBSCRIBE LIKE AND SHARE"
sleep 2
echo $p "Maaf ya gan Kalu Video nya ga jelas"
fi

if [ $BangTermux = 02 ]
then
echo $c "TERIMAKSIH TELAH MENGUNAIAN SCRIPT INI"
sleep 2
echo $r "SUBSCRIBE Channel saya gan"
sleep 3
echo $y "Ketik exit"
exit
fi
